function numberToOrdinal(n) {

    if (n == 0)
        return n;

    let str = n.toString();
    let splitted = str.split('');


    if (n > 10 && str[str.length - 2] === '1') {
        return `${n}th`
    }

    if (str.endsWith(1)) return `${n}st`
    if (str.endsWith(2)) return `${n}nd`
    if (str.endsWith(3)) return `${n}rd`

    return `${n}th`
}





for (let i = 90; i < 125; i++) {
    console.log(numberToOrdinal(i));
}

