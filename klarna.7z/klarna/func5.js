function recog(a) {
    if (a % 2 == 0) {
        return 'zoj';
    }
    else {
        return 'fard';
    }
}

var x = recog(12);
var y = recog(3753);

console.log(x);
console.log(y);