const n1 = '4556364607935616';
const n2 = '4556-3646-0793-5616';
const n3 = '64607935616';
const n4 = 'ABCD-EFGH-IJKLM-NOPQ';
const n5 = 'Nananananananananananananananana#Batman!';
function maskify(creditCard) {
    // add your code here
    let chars = creditCard.split('');
    let result = '';
    for (let i = 0; i < chars.length; i++) {
        if (!isNaN(chars[i])) {
            result += (i == 0 || i >= chars.length - 4) ? chars[i] : '#';
        }
        else if (chars[i] === '#') {
            result += ' ';
        }
        else {
            result += chars[i];
        }
    }
    return result;
}

console.log(maskify(n1))
console.log(maskify(n2))
console.log(maskify(n3))
console.log(maskify(n4))
console.log(n5)
console.log(maskify(n5))
