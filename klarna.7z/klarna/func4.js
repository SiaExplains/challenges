function jam(a, b) {
    return a + b;
}

var x = jam(5, 6);
var y = jam(99, 1);
console.log(y)