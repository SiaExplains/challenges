var s1 = "45";
var s2 = 67;
var s3 = '3';
var s4 = 'ali';
var b1 = isNaN(s4);

var b2 = true;
var b3 = !b2;
var b4 = !!!!!!!!!!!!!!!!!!!!!!!b3;

var c = 45;

var d = c.toString();

var x = d.split('')

console.log(x);