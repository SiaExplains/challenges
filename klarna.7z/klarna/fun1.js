function esm() {
    return 'ali';
}


var x = esm();

console.log(x);

