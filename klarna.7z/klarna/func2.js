function harchi(a) {
    return a;
}

var x = harchi('ali');
var y = harchi('reza');

console.log(x);
console.log(y);