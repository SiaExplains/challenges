function tavan(x) {
    return x * x;
}

var y = tavan(6);
var u = tavan(16);

console.log(y);
console.log(u);