function calculate(expression) {

    if (expression === '')
        return '0';

    let sequence = expression.split(' ');

    let operands = ['+', '-', '*', '/'];
    let stack = [];
    let stackIndex = 0;

    if (!sequence.some(item => {
        return operands.includes(item)
    })) {
        return sequence[sequence.length - 1];
    }


    stack.push(sequence[stackIndex++]);
    while (stackIndex <= sequence.length) {
        var item = sequence[stackIndex]
        var index = operands.indexOf(item)
        if (index < 0) {
            stack.push(sequence[stackIndex])
        } else {
            if (index == 0) {
                var a = parseInt(stack.splice(-1)[0], 10)
                var b = parseInt(stack.splice(-1)[0], 10)
                stack.push(a + b)
            }
            if (index == 1) {
                var a = parseInt(stack.splice(-1)[0], 10)
                var b = parseInt(stack.splice(-1)[0], 10)
                stack.push(b - a)
            }
            if (index == 2) {
                var a = parseInt(stack.splice(-1)[0], 10)
                var b = parseInt(stack.splice(-1)[0], 10)
                stack.push(a * b)
            }
            if (index == 3) {
                var a = parseInt(stack.splice(-1)[0], 10)
                var b = parseInt(stack.splice(-1)[0], 10)
                stack.push(b / a)
            }
        }
        stackIndex++
    }

    return parseInt(stack[0], 10)

}

console.log(calculate("1 2 3.5"))
console.log(calculate("10000 123 +"))
console.log(calculate("5 1 2 + 4 * + 3 -"))
//console.log(RPN(""))